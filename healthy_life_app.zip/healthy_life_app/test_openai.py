"""
OpenAI APIの接続テストスクリプト
このファイルをプロジェクトルートに作成して実行
"""
import os
from dotenv import load_dotenv

# .envファイルを読み込み
load_dotenv()

def test_api_key():
    """APIキーの存在と形式をチェック"""
    api_key = os.getenv('OPENAI_API_KEY')
    
    if not api_key:
        print("❌ OPENAI_API_KEY が設定されていません")
        print("   .envファイルを確認してください")
        return False
    
    if not api_key.startswith('sk-'):
        print(f"⚠️ APIキーの形式が正しくない可能性があります: {api_key[:10]}...")
        return False
    
    print(f"✅ APIキーを検出: {api_key[:10]}...")
    return api_key

def test_openai_direct():
    """OpenAI APIを直接テスト"""
    api_key = test_api_key()
    if not api_key:
        return
    
    try:
        from openai import OpenAI
        
        print("\n📡 OpenAI APIに接続中...")
        client = OpenAI(api_key=api_key)
        
        # シンプルなテスト
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",  # 安価なモデルでテスト
            messages=[
                {"role": "user", "content": "こんにちは。これはテストです。"}
            ],
            max_tokens=50
        )
        
        print("✅ API接続成功！")
        print(f"レスポンス: {response.choices[0].message.content}")
        return True
        
    except Exception as e:
        print(f"❌ API接続失敗: {e}")
        
        # よくあるエラーの診断
        error_str = str(e).lower()
        if "api key" in error_str or "authentication" in error_str:
            print("\n💡 対処法:")
            print("1. APIキーが正しいか確認")
            print("2. OpenAIアカウントで支払い方法が設定されているか確認")
            print("3. APIキーの使用制限に達していないか確認")
        elif "rate limit" in error_str:
            print("\n💡 レート制限に達しています。少し待ってから再試行してください。")
        elif "quota" in error_str:
            print("\n💡 使用制限に達しています。OpenAIアカウントの請求設定を確認してください。")
        
        return False

def test_langchain():
    """LangChainの設定をテスト"""
    api_key = test_api_key()
    if not api_key:
        return
    
    try:
        from langchain_openai import ChatOpenAI
        from langchain.chains import ConversationChain
        from langchain.memory import ConversationBufferMemory
        
        print("\n🔗 LangChainの設定をテスト中...")
        
        # LLMの初期化
        llm = ChatOpenAI(
            model="gpt-3.5-turbo",
            temperature=0.7,
            api_key=api_key
        )
        
        # メモリとチェーンの作成
        memory = ConversationBufferMemory()
        chain = ConversationChain(
            llm=llm,
            memory=memory,
            verbose=True
        )
        
        # テスト実行
        response = chain.invoke({"input": "こんにちは"})
        
        print("✅ LangChain設定成功！")
        print(f"レスポンス: {response}")
        return True
        
    except Exception as e:
        print(f"❌ LangChainエラー: {e}")
        import traceback
        traceback.print_exc()
        return False

if __name__ == "__main__":
    print("=" * 50)
    print("OpenAI API 接続テスト")
    print("=" * 50)
    
    # 直接API接続テスト
    if test_openai_direct():
        print("\n" + "=" * 50)
        # LangChainテスト
        test_langchain()
    
    print("\n" + "=" * 50)
    print("テスト完了")