"""栄養相談ページ"""
import streamlit as st
import os
from src.services.chat_service import HealthChatService
from src.models.user_profile import UserProfile

st.set_page_config(page_title="栄養相談", page_icon="🍎", layout="wide")

# プロフィールチェック
if 'user_profile' not in st.session_state or st.session_state.user_profile is None:
    st.warning("⚠️  プロフィールを設定してください")
    st.stop()

# チャットサービスの初期化
if 'nutrition_chat' not in st.session_state:
    api_key = os.getenv('OPENAI_API_KEY')
    if not api_key:
        st.error("🔑  OpenAI APIキーが設定されていません。.envファイルを確認してください。")
        st.stop()
    
    chat_service = HealthChatService(api_key)
    st.session_state.nutrition_chain = chat_service.create_nutrition_chain(st.session_state.user_profile)
    st.session_state.nutrition_chat = chat_service
    st.session_state.nutrition_messages = []

# ヘッダー
st.title("🍎  栄養相談チャット")
st.markdown("あなたの目標に合わせた栄養アドバイスを提供します")

# サイドバー - クイックプロンプト
with st.sidebar:
    st.subheader("💡  クイック質問")

    quick_prompts = [
        "今日の食事メニューを提案して",
        "ダイエットに効果的な食材は？",
        "腸活に良い食材は？",
        "プロテインの摂取タイミングは？",
        "間食でおすすめの食べ物は？",
        "水分補給のポイントを教えて",
        "糖質制限について教えて",
        "カロリー計算の方法は？",
        "筋肉をつける食事法は？"
    ]

    for prompt in quick_prompts:
        if st.button(prompt, use_container_width=True, key=f"quick_{prompt}"):
            st.session_state.nutrition_input = prompt

# チャット履歴の表示
chat_container = st.container()
with chat_container:
    for message in st.session_state.nutrition_messages:
        with st.chat_message(message["role"]):
            st.markdown(message["content"])

# 入力フォーム
if "nutrition_input" not in st.session_state:
    st.session_state.nutrition_input = ""

user_input = st.chat_input("栄養に関する質問を入力してください...", key="nutrition_chat_input")

if user_input or st.session_state.nutrition_input:
    input_text = user_input or st.session_state.nutrition_input
    st.session_state.nutrition_input = ""  # クリア

    # ユーザーメッセージを追加
    st.session_state.nutrition_messages.append({"role": "user", "content": input_text})
    with st.chat_message("user"):
        st.markdown(input_text)
    
    # AIレスポンスを生成
    with st.chat_message("assistant"):
        message_placeholder = st.empty()
        full_response = ""

        try:
            # 通常のレスポンス取得
            response = st.session_state.nutrition_chat.get_response(
                st.session_state.nutrition_chain, input_text
            )
            message_placeholder.markdown(response)

            st.session_state.nutrition_messages.append({"role": "assistant", "content": response})

        except Exception as e:
            st.error(f"エラーが発生しました: {str(e)}")

# フッター
with st.sidebar:
    st.markdown("---")
    if st.button("🗑️  会話履歴をクリア", use_container_width=True):
        st.session_state.nutrition_messages = []
        st.session_state.nutrition_chat.clear_nutrition_memory()
        st.rerun()
    
    st.info("""
    💡  **ヒント**:
    - 具体的な質問をすると、より詳細なアドバイスが得られます
    - あなたのプロフィールに基づいてパーソナライズされています
    """)
