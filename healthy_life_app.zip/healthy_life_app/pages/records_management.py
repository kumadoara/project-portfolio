"""記録管理ページ"""

import streamlit as st
import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
from src.models.user_profile import WorkoutRecord, NutritionRecord
from datetime import datetime, timedelta

st.set_page_config(page_title="記録管理", page_icon="📊", layout="wide")

# プロフィールチェック
if 'user_profile' not in st.session_state or st.session_state.user_profile is None:
    st.warning("⚠️  プロフィールを設定してください")
    st.stop()

st.title("📊  トレーニング・栄養記録")

# タブの作成
tab1, tab2, tab3 = st.tabs(["📈 ダッシュボード", "💪 トレーニング記録", "🍎 栄養記録"])

with tab1:
    st.subheader("週間サマリー")

    # データの読み込み
    workouts = st.session_state.data_manager.load_workouts()
    nutrition_records = st.session_state.data_manager.load_nutrition()

    if workouts and len(workouts) > 0:
        # 週間データの集計
        df_workouts = pd.DataFrame([w.model_dump() for w in workouts])
        df_workouts['date'] = pd.to_datetime(df_workouts['date'])

        # 過去7日間のデータ
        last_week = datetime.now() - timedelta(days=7)
        df_week = df_workouts[df_workouts['date'] >= last_week]

        col1, col2, col3, col4 = st.columns(4)

        with col1:
            total_workouts = len(df_week)
            st.metric("トレーニング回数", f"{total_workouts}回", delta="週間")
        
        with col2:
            total_duration = df_week['duration'].sum() if not df_week.empty else 0  
            st.metric("総運動時間", f"{total_duration}分", delta=f"{total_duration//60}時間{total_duration%60}分")
        
        with col3:
            total_calories = df_week['calories'].sum() if not df_week.empty else 0  
            st.metric("消費カロリー", f"{total_calories:,.0f} kcal", delta="週間合計")
        
        with col4:
            avg_intensity = df_week['intensity'].mode()[0] if not df_week.empty else "なし"  
            st.metric("平均強度", avg_intensity, delta="最頻値")

        # グラフ表示
        st.markdown("---")

        graph_col1, graph_col2 = st.columns(2)

        with graph_col1:
            # 日別カロリー消費グラフ
            if not df_week.empty:
                try:
                    daily_calories = df_week.groupby(df_week['date'].dt.date)['calories'].sum().reset_index()
                    if not daily_calories.empty():
                        fig = px.bar(
                            daily_calories,
                            x='date',
                            y='calories',
                            title='日別消費カロリー',
                            labels={'calories': 'カロリー（kcal）', 'date': '日付'},
                            color_discrete_sequence=['#667eea']
                        )
                        fig.update_layout(height=400)
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("期間中のデータがありません")
                except Exception as e:
                    st.error(f"グラフ作成エラー: {str(e)}")
            else:
                st.info("まだデータがありません。")

        with graph_col2:
            # 運動種目別の分布
            if not df_week.empty and 'exercise' in df_week.columns:
                try:
                    exercise_dist = df_week['exercise'].value_counts().reset_index()
                    exercise_dist.columns = ['exercise', 'count']
                    if not exercise_dist.empty:
                        fig = px.pie(
                            exercise_dist, 
                            values='count', 
                            names='exercise',
                            title='運動種目の分布',
                            color_discrete_sequence=px.colors.sequential.Viridis
                        )
                        fig.update_layout(height=400)
                        st.plotly_chart(fig, use_container_width=True)
                    else:
                        st.info("データがありません")
                except Exception as e:
                    st.error(f"グラフ作成エラー: {str(e)}")
            else:
                st.info("まだデータがありません")

        # 週間トレンド
        st.markdown("### 📈  週間トレンド")

        try:
            # 週番号と年を追加
            df_workouts['week'] = df_workouts['date'].dt.isocalendar().week
            df_workouts['year'] = df_workouts['date'].dt.year

            # 年と週でグループ化
            weekly_stats = df_workouts.groupby(['year', 'week']).agg({
                'duration': 'sum',
                'calories': 'sum',
                'exercise': 'count'
            }).tail(4).reset_index()

            if not weekly_stats.empty:
                # 週の表示用ラベルを作成
                weekly_stats['week_label'] = 'w' + weekly_stats['week'].astype(str)

                fig = go.Figure()
                fig.add_trace(go.Scatter(
                    x=weekly_stats['week_label'],
                    y=weekly_stats['duration'],
                    mode='lines+markers',
                    name='運動時間（分）',
                    yaxis='y'
                ))
                fig.add_trace(go.Scatter(
                    x=weekly_stats['week_label'],
                    y=weekly_stats['calories'],
                    mode='lines+markers',
                    name='消費カロリー',
                    yaxis='y2'
                ))

                fig.update_layout(
                    title='週間トレーニングトレンド',
                    xaxis_title='週',
                    yaxis=dict(title='運動時間（分）', side='left'),
                    yaxis2=dict(title='消費カロリー', overlaying='y', side='right'),
                    height=400
                )
                st.plotly_chart(fig, use_container_width=True)
            else:
                st.info("トレンドを表示するには、もう少しデータが必要です")
        except Exception as e:
            st.error(f"トレンド作成エラー: {str(e)}")
    
    else:
        # workoutが空の場合
        st.info("📝 トレーニング記録を始めましょう！")
        st.markdown("""
        トレーニングチャットページから記録を追加するか、
        「トレーニング記録」タブから手動で追加できます。
        """)

with tab2:
    st.subheader("💪 トレーニング履歴")
    
    # トレーニング記録の追加フォーム
    with st.expander("➕ 新しいトレーニング記録を追加", expanded=False):
        with st.form("add_workout_form"):
            form_col1, form_col2 = st.columns(2)
            
            with form_col1:
                exercise = st.text_input("運動名", placeholder="例: ランニング")
                duration = st.number_input("時間（分）", min_value=1, max_value=300, value=30)
                intensity = st.select_slider(
                    "強度",
                    options=["低", "中", "高"],
                    value="中"
                )
            
            with form_col2:
                calories = st.number_input("消費カロリー", min_value=0, max_value=2000, value=200)
                workout_date = st.date_input("日付", value=datetime.now())
                notes = st.text_area("メモ", placeholder="任意")
            
            submitted = st.form_submit_button("記録を追加", use_container_width=True)
            
            if submitted and exercise:
                record = WorkoutRecord(
                    date=datetime.combine(workout_date, datetime.now().time()),
                    exercise=exercise,
                    duration=duration,
                    calories=calories,
                    intensity=intensity,
                    notes=notes if notes else None
                )
                try:
                    if st.session_state.data_manager.save_workout(record):
                        st.success("✅ トレーニング記録を追加しました！")
                        st.rerun()
                except Exception as e:
                    st.error(f"保存エラー: {str(e)}")
            elif submitted:
                st.error("運動名を入力してください")
    
    # 既存の記録を表示
    workouts_tab2 = st.session_state.data_manager.load_workouts()
    
    if workouts_tab2 and len(workouts_tab2) > 0:
        # フィルター
        filter_col1, filter_col2, filter_col3 = st.columns(3)
        
        with filter_col1:
            date_filter = st.date_input(
                "期間",
                value=(datetime.now() - timedelta(days=30), datetime.now()),
                format="YYYY-MM-DD",
                key="workout_date_filter"
            )
        
        with filter_col2:
            exercise_list = list(set([w.exercise for w in workouts_tab2]))
            exercise_filter = st.multiselect("運動種目", exercise_list, key="exercise_filter")
        
        with filter_col3:
            intensity_filter = st.multiselect("強度", ["低", "中", "高"], key="intensity_filter")
        
        # データフレームの作成とフィルタリング
        df_tab2 = pd.DataFrame([w.model_dump() for w in workouts_tab2])
        df_tab2['date'] = pd.to_datetime(df_tab2['date'])
        
        # フィルター適用
        if len(date_filter) == 2:
            mask = (df_tab2['date'].dt.date >= date_filter[0]) & (df_tab2['date'].dt.date <= date_filter[1])
            df_tab2 = df_tab2[mask]
        
        if exercise_filter:
            df_tab2 = df_tab2[df_tab2['exercise'].isin(exercise_filter)]
        
        if intensity_filter:
            df_tab2 = df_tab2[df_tab2['intensity'].isin(intensity_filter)]
        
        # 表示
        if not df_tab2.empty:
            df_display = df_tab2.sort_values('date', ascending=False).copy()
            df_display['date'] = df_display['date'].dt.strftime('%Y-%m-%d %H:%M')
            
            # notesがNoneの場合を処理
            if 'notes' in df_display.columns:
                df_display['notes'] = df_display['notes'].fillna('')
            
            st.dataframe(
                df_display[['date', 'exercise', 'duration', 'calories', 'intensity', 'notes']],
                use_container_width=True,
                hide_index=True,
                column_config={
                    "date": "日時",
                    "exercise": "運動",
                    "duration": st.column_config.NumberColumn("時間（分）", format="%d 分"),
                    "calories": st.column_config.NumberColumn("カロリー", format="%d kcal"),
                    "intensity": "強度",
                    "notes": "メモ"
                }
            )
            
            # エクスポート機能
            csv = df_display.to_csv(index=False, encoding='utf-8-sig')
            st.download_button(
                label="📥 CSVダウンロード",
                data=csv,
                file_name=f"workout_history_{datetime.now().strftime('%Y%m%d')}.csv",
                mime="text/csv"
            )
        else:
            st.info("指定された条件に一致する記録がありません")
    else:
        st.info("まだトレーニング記録がありません。上のフォームから記録を追加してください。")

with tab3:
    st.subheader("🍎 栄養記録")
    
    # 栄養記録の追加フォーム
    with st.expander("➕ 新しい食事記録を追加", expanded=False):
        with st.form("add_nutrition_form"):
            nutrition_col1, nutrition_col2 = st.columns(2)
            
            with nutrition_col1:
                meal_type = st.selectbox("食事タイプ", ["朝食", "昼食", "夕食", "間食"])
                meal_date = st.date_input("日付", value=datetime.now(), key="meal_date")
                meal_time = st.time_input("時間", value=datetime.now().time())
            
            with nutrition_col2:
                st.markdown("### 食品情報")
                food_name = st.text_input("食品名", placeholder="例: 鶏胸肉")
                calories = st.number_input("カロリー (kcal)", min_value=0, value=0)
                protein = st.number_input("タンパク質 (g)", min_value=0.0, value=0.0)
                carbs = st.number_input("炭水化物 (g)", min_value=0.0, value=0.0)
                fat = st.number_input("脂質 (g)", min_value=0.0, value=0.0)
            
            nutrition_notes = st.text_area("メモ（任意）", key="nutrition_notes")
            
            nutrition_submitted = st.form_submit_button("記録を保存", use_container_width=True)
            
            if nutrition_submitted:
                if food_name and calories > 0:
                    record = NutritionRecord(
                        date=datetime.combine(meal_date, meal_time),
                        meal_type=meal_type,
                        foods=[{
                            "name": food_name,
                            "calories": float(calories),
                            "protein": float(protein),
                            "carbs": float(carbs),
                            "fat": float(fat)
                        }],
                        total_calories=float(calories),
                        notes=nutrition_notes if nutrition_notes else None
                    )
                    
                    try:
                        if st.session_state.data_manager.save_nutrition(record):
                            st.success("✅ 栄養記録を保存しました！")
                            st.rerun()
                    except Exception as e:
                        st.error(f"保存エラー: {str(e)}")
                else:
                    st.error("食品名とカロリーを入力してください")
    
    # 栄養記録の表示
    nutrition_records_tab3 = st.session_state.data_manager.load_nutrition()
    
    if nutrition_records_tab3 and len(nutrition_records_tab3) > 0:
        df_nutrition = pd.DataFrame([n.model_dump() for n in nutrition_records_tab3])
        df_nutrition['date'] = pd.to_datetime(df_nutrition['date'])
        
        # 今日の栄養摂取
        today = datetime.now().date()
        today_records = df_nutrition[df_nutrition['date'].dt.date == today]
        
        if not today_records.empty:
            st.markdown("### 📅 今日の栄養摂取")
            
            today_col1, today_col2, today_col3, today_col4 = st.columns(4)
            
            total_calories_today = today_records['total_calories'].sum()
            
            # 目標カロリーの計算
            from src.utils.helpers import calculate_bmr, calculate_tdee
            
            try:
                bmr = calculate_bmr(
                    st.session_state.user_profile.height,
                    st.session_state.user_profile.weight,
                    st.session_state.user_profile.age,
                    st.session_state.user_profile.gender
                )
                tdee = calculate_tdee(bmr, st.session_state.user_profile.activity_level)
                
                if st.session_state.user_profile.goal == "減量":
                    target_calories = tdee - 500
                elif st.session_state.user_profile.goal == "増量":
                    target_calories = tdee + 500
                else:
                    target_calories = tdee
                
                with today_col1:
                    st.metric("摂取カロリー", f"{total_calories_today:.0f} kcal")
                with today_col2:
                    st.metric("目標カロリー", f"{target_calories:.0f} kcal")
                with today_col3:
                    remaining = target_calories - total_calories_today
                    st.metric("残りカロリー", f"{remaining:.0f} kcal", 
                             delta=f"{remaining/target_calories*100:.1f}%" if target_calories > 0 else "0%")
                with today_col4:
                    achievement = (total_calories_today / target_calories) * 100 if target_calories > 0 else 0
                    st.metric("達成率", f"{achievement:.1f}%")
            except Exception as e:
                st.error(f"カロリー計算エラー: {str(e)}")
        
        # 履歴表示
        st.markdown("### 📋 食事履歴")
        
        if not df_nutrition.empty:
            df_display = df_nutrition.sort_values('date', ascending=False).copy()
            df_display['date_str'] = df_display['date'].dt.strftime('%Y-%m-%d %H:%M')
            
            # 最新10件を表示
            for idx, row in df_display.head(10).iterrows():
                with st.expander(f"{row['date_str']} - {row['meal_type']} ({row['total_calories']:.0f} kcal)"):
                    if isinstance(row['foods'], list):
                        for food in row['foods']:
                            if isinstance(food, dict):
                                st.write(f"**{food.get('name', '不明')}**")
                                food_info_col1, food_info_col2, food_info_col3, food_info_col4 = st.columns(4)
                                with food_info_col1:
                                    st.write(f"カロリー: {food.get('calories', 0):.0f} kcal")
                                with food_info_col2:
                                    st.write(f"タンパク質: {food.get('protein', 0):.1f}g")
                                with food_info_col3:
                                    st.write(f"炭水化物: {food.get('carbs', 0):.1f}g")
                                with food_info_col4:
                                    st.write(f"脂質: {food.get('fat', 0):.1f}g")
                    if row.get('notes'):
                        st.write(f"📝 メモ: {row['notes']}")
        else:
            st.info("栄養記録がありません")
    else:
        st.info("まだ栄養記録がありません。上のフォームから記録を追加してください。")
