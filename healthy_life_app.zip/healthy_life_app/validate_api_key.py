import os
from dotenv import load_dotenv

# .envを再読み込み
load_dotenv(override=True)

def validate_api_key():
    """APIキーの形式と内容を詳細にチェック"""
    
    api_key = os.getenv('OPENAI_API_KEY')
    
    print("=" * 60)
    print("APIキー検証")
    print("=" * 60)
    
    if not api_key:
        print("❌ APIキーが見つかりません")
        print("   .envファイルが存在し、正しく記述されているか確認してください")
        return False
    
    # 長さをチェック
    print(f"📏 キーの長さ: {len(api_key)} 文字")
    if len(api_key) < 40:
        print("   ⚠️ キーが短すぎます。完全にコピーされていない可能性があります")
    
    # 先頭をチェック
    if api_key.startswith('sk-'):
        print(f"✅ キーの形式: 正しい (sk-で始まる)")
    else:
        print(f"❌ キーの形式: 間違い (先頭: {api_key[:5]})")
        return False
    
    # 余計な文字をチェック
    if api_key.startswith('"') or api_key.endswith('"'):
        print("❌ 引用符が含まれています")
        return False
    
    if ' ' in api_key:
        print("❌ スペースが含まれています")
        return False
    
    if '\n' in api_key or '\r' in api_key:
        print("❌ 改行が含まれています")
        return False
    
    # 表示用にマスク
    if len(api_key) > 20:
        masked = f"{api_key[:20]}...{api_key[-4:]}"
    else:
        masked = api_key[:10] + "..."
    
    print(f"🔑 検出されたキー: {masked}")
    
    # 実際にAPIをテスト
    print("\n📡 OpenAI APIに接続テスト中...")
    
    try:
        from openai import OpenAI
        client = OpenAI(api_key=api_key)
        
        # 最小限のテスト
        response = client.chat.completions.create(
            model="gpt-3.5-turbo",
            messages=[{"role": "user", "content": "Hi"}],
            max_tokens=5
        )
        
        print("✅ API接続成功！キーは有効です")
        return True
        
    except Exception as e:
        error_msg = str(e)
        
        if "401" in error_msg or "invalid_api_key" in error_msg:
            print("❌ APIキーが無効です")
            print("   → 新しいキーを生成してください")
        elif "insufficient_quota" in error_msg:
            print("❌ APIの使用制限に達しています")
            print("   → OpenAIアカウントの支払い設定を確認してください")
        elif "429" in error_msg:
            print("⚠️ レート制限です。しばらく待ってから再試行してください")
        else:
            print(f"❌ エラー: {error_msg[:200]}")
        
        return False

if __name__ == "__main__":
    if validate_api_key():
        print("\n" + "=" * 60)
        print("🎉 APIキーは正常に動作しています！")
        print("Streamlitアプリを起動できます: streamlit run app.py")
    else:
        print("\n" + "=" * 60)
        print("📝 対処法:")
        print("1. OpenAIで新しいAPIキーを生成")
        print("2. .envファイルに正しく設定")
        print("3. このスクリプトを再実行して確認")
        