"""
ユーザーデータモデル
ユーザーの基本情報と健康目標を管理
"""

from pydantic import BaseModel
from typing import Optional, List, Dict
from datetime import datetime

class UserProfile(BaseModel):
    """ユーザープロフィール情報を格納するクラス"""

    name: str
    age: int
    gender: str
    height: float   # cm
    weight: float   # kg
    activity_level: str
    goal: str
    created_at: datetime = datetime.now()
    updated_at: datetime = datetime.now()

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }

class WorkoutRecord(BaseModel):
    """ワークアウト記録情報を格納するクラス"""
    date: datetime
    exercise: str
    duration: int #minutes
    calories: int
    intensity : str
    notes: Optional[str] = None

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }


class NutritionRecord(BaseModel):
    """栄養記録情報を格納するクラス"""
    date: datetime
    meal_type: str # 朝食、昼食、夕食、間食
    foods: List[Dict[str, float]] # {"name": "food", "calories": 100, "protein": 10, .... }
    total_calories: float
    notes: Optional[str] = None

    class Config:
        json_encoders = {
            datetime: lambda v: v.isoformat()
        }
